package id.mini.karakter

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.view.accessibility.AccessibilityNodeInfo
import java.io.File

// Perintah untuk mengoperasikan HP. Hanya dari perintah yang kamu ketik (bukan dari teks layar atau jawaban AI).
// Pengaturan/izin diblokir, dan ada daftar kata berisiko yang tidak akan diketuk.
object Aksi {
    val BLOKIR = setOf("com.android.settings", "com.android.permissioncontroller", "com.google.android.permissioncontroller",
        "com.miui.securitycenter", "com.android.packageinstaller", "com.google.android.packageinstaller")
    private val BLOK_NAMA = listOf("pengaturan", "setelan", "settings", "setting")
    private val RISIKO = listOf("izinkan", "allow", "install", "pasang", "copot", "uninstall", "reset", "hapus semua",
        "bayar", "transfer", "kirim uang", "factory")
    private val RE = Regex("^(buka|ketuk|klik|ketik|scroll|gulir|kembali|back|home|beranda|recent|terbaru|notifikasi|baca layar|cari file|baca file|daftar aplikasi)\\b.*")
    private val EKSTENSI = setOf("txt", "py", "js", "json", "md", "log", "java", "kt", "cpp", "ino", "html", "css", "sh", "csv", "xml", "yml", "yaml")

    fun cocok(l: String): Boolean = RE.matches(l.trim().lowercase())

    fun coba(ctx: Context, raw: String): String? {
        val t = raw.trim()
        val l = t.lowercase()
        if (!cocok(l)) return null
        if (l.startsWith("cari file ")) return cariFile(t.substring(10).trim())
        if (l.startsWith("baca file ")) return bacaFile(t.substring(10).trim())
        if (l.startsWith("buka ")) return buka(ctx, t.substring(5).trim())
        if (l == "daftar aplikasi") return daftar(ctx)
        val svc = LayarService.inst ?: return "Aktifkan dulu akses layar untuk Mini (menu utama app, tombol 2)."
        val pkg = svc.akar()?.packageName?.toString()
        if (pkg != null && pkg in BLOKIR) return "Aku tidak menyentuh Pengaturan/izin. Pindah ke app lain dulu."
        return when {
            l == "kembali" || l == "back" -> glob(svc, AccessibilityService.GLOBAL_ACTION_BACK, "Oke, kembali.")
            l == "home" || l == "beranda" -> glob(svc, AccessibilityService.GLOBAL_ACTION_HOME, "Oke, ke beranda.")
            l == "recent" || l == "terbaru" -> glob(svc, AccessibilityService.GLOBAL_ACTION_RECENTS, "Oke, app terbaru.")
            l == "notifikasi" -> glob(svc, AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Oke, notifikasi.")
            l == "baca layar" -> svc.teks().take(1500).ifBlank { "Layar kosong atau tidak terbaca." }
            l.startsWith("klik ") || l.startsWith("ketuk ") -> klik(svc, t.substringAfter(' ').trim())
            l.startsWith("ketik ") -> ketik(svc, t.substring(6))
            l.startsWith("scroll") || l.startsWith("gulir") -> scroll(svc, l)
            else -> null
        }
    }

    private fun glob(svc: AccessibilityService, kode: Int, ok: String): String =
        if (svc.performGlobalAction(kode)) ok else "Gagal menjalankan perintah."

    private fun buka(ctx: Context, nama: String): String {
        val n = nama.lowercase()
        if (BLOK_NAMA.any { n.contains(it) }) return "Aku tidak membuka Pengaturan."
        val pm = ctx.packageManager
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hasil = pm.queryIntentActivities(li, 0)
            .filter { it.activityInfo.packageName !in BLOKIR }
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        val pilih = hasil.firstOrNull { it.first.lowercase() == n }
            ?: hasil.firstOrNull { it.first.lowercase().contains(n) }
            ?: return "Aplikasi '$nama' tidak ketemu. Ketik 'daftar aplikasi'."
        val i = pm.getLaunchIntentForPackage(pilih.second) ?: return "Tidak bisa membuka ${pilih.first}."
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "Membuka ${pilih.first}."
    }

    private fun daftar(ctx: Context): String {
        val pm = ctx.packageManager
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val n = pm.queryIntentActivities(li, 0).filter { it.activityInfo.packageName !in BLOKIR }
            .map { it.loadLabel(pm).toString() }.distinct().sorted()
        return "Aplikasi (${n.size}):\n" + n.take(60).joinToString(", ")
    }

    private fun berisiko(t: String): Boolean {
        val l = t.lowercase()
        return BLOK_NAMA.any { l.contains(it) } || RISIKO.any { l.contains(it) }
    }

    private fun klik(svc: LayarService, teks: String): String {
        if (berisiko(teks)) return "Itu berisiko (izin/pengaturan/pembayaran). Lakukan sendiri ya."
        val root = svc.akar() ?: return "Layar tidak terbaca."
        val cari = root.findAccessibilityNodeInfosByText(teks)
        if (cari.isEmpty()) return "Tidak ada '$teks' di layar."
        var n: AccessibilityNodeInfo? = cari[0]
        while (n != null && !n.isClickable) n = n.parent
        return if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) "Kuketuk '$teks'." else "Ketemu '$teks' tapi tidak bisa diketuk."
    }

    private fun ketik(svc: LayarService, teks: String): String {
        val f = svc.akar()?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "Tidak ada kolom teks yang aktif. Ketuk kolomnya dulu."
        if (f.isPassword) return "Itu kolom kata sandi, aku tidak mengisinya."
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, (f.text?.toString() ?: "") + teks)
        return if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "Sudah kuketik." else "Gagal mengetik."
    }

    private fun scroll(svc: LayarService, l: String): String {
        val root = svc.akar() ?: return "Layar tidak terbaca."
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        var n = 0
        while (q.isNotEmpty() && n < 300) {
            val nd = q.removeFirst()
            n++
            if (nd.isScrollable) {
                val aksi = if (l.contains("atas")) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                return if (nd.performAction(aksi)) "Oke, kugulir." else "Tidak bisa digulir lagi."
            }
            for (i in 0 until nd.childCount) nd.getChild(i)?.let { q.add(it) }
        }
        return "Tidak ada yang bisa digulir."
    }

    private fun cariFile(kata: String): String {
        val root = Environment.getExternalStorageDirectory()
        val k = kata.lowercase()
        if (k.isEmpty()) return "Format: cari file <kata>"
        val hasil = ArrayList<String>()
        var dilihat = 0
        fun jalan(d: File, depth: Int) {
            if (hasil.size >= 20 || depth > 6 || dilihat > 8000) return
            val daftar = d.listFiles() ?: return
            for (f in daftar) {
                dilihat++
                if (f.name.startsWith(".")) continue
                if (f.name.lowercase().contains(k)) hasil.add(f.absolutePath.removePrefix(root.absolutePath + "/"))
                if (f.isDirectory) jalan(f, depth + 1)
                if (hasil.size >= 20 || dilihat > 8000) return
            }
        }
        jalan(root, 0)
        return if (hasil.isEmpty()) "Tidak ketemu (atau izin file belum diberikan, tombol 4 di menu utama)." else "Ketemu:\n" + hasil.joinToString("\n")
    }

    private fun bacaFile(path: String): String {
        val root = Environment.getExternalStorageDirectory()
        val f = if (path.startsWith("/")) File(path) else File(root, path)
        if (!f.isFile) return "File tidak ditemukan: $path"
        if (f.extension.lowercase() !in EKSTENSI) return "Aku hanya membaca file teks/kode (txt, py, js, json, md, log, dll)."
        if (f.length() > 200_000) return "File terlalu besar (maks 200 KB)."
        return try { f.name + "\n\n" + f.readText().take(3000) } catch (e: Exception) { "Gagal membaca file." }
    }
}
