package id.mini.karakter

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

// Membaca teks layar secara lokal dan menjalankan perintah Aksi. Pengaturan/izin diabaikan.
class LayarService : AccessibilityService() {
    companion object {
        var inst: LayarService? = null
    }

    private var tLast = 0L
    private var sel: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        inst = null
        return super.onUnbind(intent)
    }

    // Jendela aplikasi teratas selain Mini sendiri (panel Mini adalah overlay, bukan jendela aplikasi).
    fun akar(): AccessibilityNodeInfo? {
        val w = windows.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }.sortedByDescending { it.layer }
        for (x in w) {
            val r = x.root
            if (r != null && r.packageName?.toString() != packageName) return r
        }
        return rootInActiveWindow
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg in Aksi.BLOKIR) return
        var paksa = false
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED) {
            val t = (e.source?.text ?: e.text.firstOrNull())?.toString()
            if (t != null && e.fromIndex >= 0 && e.toIndex > e.fromIndex && e.toIndex <= t.length) {
                sel = t.substring(e.fromIndex, e.toIndex)
                paksa = true
            }
        }
        val now = System.currentTimeMillis()
        if (!paksa && now - tLast < 2500) return
        tLast = now
        val isi = teks()
        val s = sel
        sel = null
        Shared.onLayar(this, pkg, isi, s)
    }

    fun teks(): String {
        val root = akar() ?: return ""
        val sb = StringBuilder()
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        var n = 0
        while (q.isNotEmpty() && n < 300 && sb.length < 4000) {
            val nd = q.removeFirst()
            n++
            if (!nd.isPassword) {
                val t = nd.text
                if (!t.isNullOrBlank()) sb.append(t).append('\n')
            }
            for (i in 0 until nd.childCount) nd.getChild(i)?.let { q.add(it) }
        }
        return sb.toString()
    }

    override fun onInterrupt() {}
}
