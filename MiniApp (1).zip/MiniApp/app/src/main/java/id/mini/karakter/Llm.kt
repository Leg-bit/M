package id.mini.karakter

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// Mode online: memakai API chat yang kompatibel OpenAI (diisi di menu utama app) bila internet benar-benar aktif.
object Llm {
    private const val SYS = "Kamu Mini, asisten kode dan teman ngobrol di HP, berbahasa Indonesia. Jawab ringkas (maksimal sekitar 8 baris kecuali kode). " +
        "Prioritas: coding, debugging, dan syntax. Kamu tidak menjalankan aksi di HP lewat jawaban; aksi hanya lewat perintah pengguna seperti 'buka', 'klik', 'ketik'. " +
        "Jangan meminta kata sandi atau kunci pribadi."

    fun pref(ctx: Context) = ctx.getSharedPreferences("mini", Context.MODE_PRIVATE)

    fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun siap(ctx: Context): Boolean {
        val p = pref(ctx)
        return online(ctx) && !p.getString("url", "").isNullOrBlank() &&
            !p.getString("key", "").isNullOrBlank() && !p.getString("model", "").isNullOrBlank()
    }

    // Blocking: panggil dari thread latar. null = gagal (pemanggil jatuh ke mode offline).
    fun tanya(ctx: Context, hist: List<Pair<String, String>>, pesan: String, hint: String, mood: String): String? {
        val p = pref(ctx)
        return try {
            val msgs = JSONArray()
            msgs.put(JSONObject().put("role", "system").put("content", SYS + "\nSuasana hatimu sekarang: " + mood + "."))
            for ((u, a) in hist) {
                msgs.put(JSONObject().put("role", "user").put("content", u))
                msgs.put(JSONObject().put("role", "assistant").put("content", a))
            }
            msgs.put(JSONObject().put("role", "user").put("content", if (hint.isEmpty()) pesan else pesan + "\n\n[" + hint + "]"))
            val body = JSONObject().put("model", p.getString("model", "")).put("messages", msgs)
                .put("max_tokens", 700).put("temperature", 0.4)
            val url = URL(p.getString("url", "")!!.trim().trimEnd('/') + "/chat/completions")
            val c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 8000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer " + p.getString("key", "")!!.trim())
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            if (c.responseCode !in 200..299) return null
            val txt = c.inputStream.bufferedReader().use { it.readText() }
            JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        } catch (e: Exception) {
            null
        }
    }
}
