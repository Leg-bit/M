package id.mini.karakter

import android.content.Context

object Kat {
    private val PKG = mapOf(
        "coding" to listOf("ru.iiec.pydroid3", "com.termux", "com.aide.ui", "com.foxdebug.acode", "com.replit.app"),
        "video" to listOf("com.google.android.youtube", "com.netflix.mediaclient", "app.revanced.android.youtube", "tv.twitch.android.app", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
        "game" to listOf("com.mojang.minecraftpe", "com.roblox.client", "com.dts.freefireth", "com.mobile.legends", "com.tencent.ig"),
        "chat" to listOf("com.whatsapp", "org.telegram.messenger", "com.facebook.orca"),
        "sosmed" to listOf("com.instagram.android", "com.facebook.katana", "com.twitter.android"),
        "browse" to listOf("com.android.chrome", "org.mozilla.firefox", "com.opera.browser", "com.brave.browser"),
        "music" to listOf("com.spotify.music", "com.google.android.apps.youtube.music"),
        "settings" to listOf("com.android.settings")
    )
    private val P2K: Map<String, String> = PKG.flatMap { (k, l) -> l.map { it to k } }.toMap()
    val LABEL = mapOf("coding" to "coding", "video" to "nonton", "game" to "main game", "chat" to "chat", "sosmed" to "sosmed",
        "browse" to "browsing", "music" to "dengerin musik", "home" to "di layar utama", "settings" to "buka pengaturan")
    val KW = mapOf(
        "coding" to listOf("coding", "ngoding", "kode", "program", "script", "debug", "python", "bikin", "error"),
        "video" to listOf("nonton", "video", "youtube", "film", "tonton", "lihat"),
        "game" to listOf("main", "game", "maen", "gim"),
        "chat" to listOf("chat", "wa", "ngobrol", "balas", "pesan", "telegram"),
        "sosmed" to listOf("scroll", "sosmed", "ig", "instagram", "tiktok", "lihat"),
        "browse" to listOf("cari", "browsing", "internet", "baca", "googling"),
        "music" to listOf("dengar", "denger", "lagu", "musik"),
        "home" to listOf("nganggur", "santai", "istirahat", "diam"),
        "settings" to listOf("atur", "setting", "pengaturan")
    )
    val QL = mapOf(
        "coding" to listOf("Apa yang kamu lakukan?", "Lagi bikin apa? Kodenya error nggak?", "Itu bahasa pemrograman apa yang kamu pakai?"),
        "video" to listOf("Kamu nonton apa?", "Videonya tentang apa? Seru nggak?", "Boleh ikut nonton?"),
        "game" to listOf("Lagi main apa? Menang nggak?", "Susah nggak gamenya?"),
        "chat" to listOf("Lagi ngobrol sama teman ya?", "Lagi sibuk balas pesan?"),
        "sosmed" to listOf("Lagi scroll apa? Ada yang seru?"),
        "browse" to listOf("Lagi cari apa di internet?", "Lagi baca apa?"),
        "music" to listOf("Lagi dengerin lagu apa?", "Lagunya enak nggak?"),
        "home" to listOf("Lagi nganggur ya? Mau ngobrol?", "Kamu mau ngapain habis ini?"),
        "settings" to listOf("Lagi ngatur apa? Ada yang bermasalah?")
    )

    fun kategori(pkg: String): String? {
        if (pkg == "id.mini.karakter" || pkg == "android" || pkg == "com.android.systemui" ||
            pkg.contains("inputmethod") || pkg.contains("keyboard")) return null
        P2K[pkg]?.let { return it }
        if (pkg.contains("launcher")) return "home"
        return "lain"
    }
}

class Brain(ctx: Context) {
    private val app: Context = ctx.applicationContext
    private val history = ArrayList<Pair<String, String>>()
    private val kb = Kb(ctx)
    private val dbg = Debugger(ctx)
    private val chat = Chat(ctx)
    val mood = Mood()

    private class Tanya(val kunci: String, val kat: String?, val t: Long)
    private var pending: Tanya? = null
    private var tunggu: String? = null
    private var abai = 0
    private var lastSel = ""
    private var lastErr = ""
    private var tErr = 0L
    private var katNow = ""
    private var stabil = 0
    private var tAsk = 0L

    // ---- obrolan / perintah dari kamu ----
    fun balas(raw: String): String? {
        val t = raw.trim()
        val l = t.lowercase()
        if (mood.sedangDiam() && l != "/bicara" && l != "bicara" && l != "/bangun") return null

        Aksi.coba(app, t)?.let { r ->
            return if (l.startsWith("baca file") && Decision.adaError(r)) r + "\n\n" + (dbg.analisis(r) ?: "") else r
        }

        val ragu = tunggu
        if (ragu != null) {
            tunggu = null
            val w = tok(l)
            if (w.any { it == "syntax" || it == "sintaks" || it == "kode" || it == "contoh" }) return kode(ragu)
            if (w.any { it == "error" || it == "debug" || it == "salah" || it == "eror" || it == "bug" }) return debug(ragu)
        }

        val d = Decision.putuskan(t)
        val cmd = d.intent == Niat.TEACH || d.intent == Niat.CORRECT || d.intent == Niat.BICARA || d.intent == Niat.DIAM
        val p = pending
        if (p != null && !cmd && d.intent != Niat.DEBUG) {
            pending = null
            abai = 0
            chat.ajar(p.kunci, t)
            return if (p.kat != null) reaksi(p.kat, t) else "Oke, aku ingat!"
        }
        if (d.ragu) {
            tunggu = t
            return "Maksudmu cari contoh kode (balas: syntax) atau periksa error (balas: error)?"
        }
        return when (d.intent) {
            Niat.BICARA -> { mood.diamSampai = 0; "Iya, aku bicara lagi!" }
            Niat.DIAM -> { mood.diam(parseDur(l)); "Oke... aku diam." }
            Niat.TEACH -> ajar(t)
            Niat.CORRECT -> if (chat.koreksi(t.substring(9).trim())) "Oke, sudah kuperbaiki!" else "Belum ada jawaban obrolan untuk dikoreksi."
            Niat.DEBUG -> debug(t)
            Niat.KODE -> kode(t)
            Niat.CHAT -> ngobrol(t)
        }
    }

    private fun parseDur(l: String): Long {
        val m = Decision.DIAM.matchEntire(l) ?: return 300
        val n = m.groupValues[1].toLongOrNull() ?: return 300
        return when (m.groupValues[2]) { "jam" -> n * 3600; "menit", "mnt" -> n * 60; else -> n }
    }

    private fun ajar(t: String): String {
        val body = t.substring(6)
        val i = body.indexOf('=')
        if (i < 0) return "Format: /ajar tanya = jawab"
        chat.ajar(body.substring(0, i).trim(), body.substring(i + 1).trim())
        return "Oke, dicatat!"
    }

    private fun debug(t: String): String =
        dbg.analisis(t) ?: "Aku belum mengenali error ini. Kirim baris terakhir errornya (mis. NameError: ...), atau ajari aku: /ajar tanya = jawab"

    private fun kode(t: String): String {
        val h = kb.cari(t)
        if (h.isEmpty()) return chat.jawab(t) ?: "Belum ada contoh itu di perpustakaanku. Coba kata kunci lain (mis. 'for loop python'), atau ajari aku: /ajar tanya = jawab"
        val s = h[0]
        var out = "▸ ${s.j} [${s.b}]\n${s.c}"
        if (h.size > 1) out += "\n\nMungkin juga: " + h.drop(1).joinToString(", ") { "${it.j} [${it.b}]" }
        return out
    }

    private fun ngobrol(t: String): String {
        mood.rasakan(tok(t))
        val r = chat.jawab(t) ?: "Aku belum tahu. Ajari aku dengan: /ajar tanya = jawab"
        return mood.gaya(r)
    }

    private fun reaksi(kat: String, t: String): String {
        val w = tok(t).toSet()
        val kw = Kat.KW[kat] ?: emptyList()
        return if (w.any { it in kw }) {
            mood.tambah(Em.CERIA, 0.3)
            listOf("Ohhhh, iya! Aku lihat kok.", "Ohhh begitu, pantesan!", "Ohh oke, semangat ya!").random()
        } else {
            mood.tambah(Em.PENASARAN, 0.3)
            "Hmm, aku lihatnya kamu lagi ${Kat.LABEL[kat] ?: kat} sih. Tapi oke, '${t.take(40)}' ya... ohhh."
        }
    }

    // ---- mode online (API) ----
    fun perlukanLlm(raw: String): Boolean {
        if (mood.sedangDiam() || pending != null || tunggu != null || !Llm.siap(app)) return false
        val t = raw.trim()
        if (Aksi.cocok(t.lowercase())) return false
        val i = Decision.putuskan(t).intent
        return i == Niat.CHAT || i == Niat.KODE || i == Niat.DEBUG
    }

    // Blocking: panggil dari thread latar. null = gagal, pemanggil memakai jawaban offline.
    fun llm(raw: String): String? {
        val t = raw.trim()
        mood.rasakan(tok(t))
        val d = Decision.putuskan(t)
        val hint = StringBuilder()
        if (d.intent == Niat.DEBUG) dbg.analisis(t)?.let { hint.append("Catatan perpustakaan lokal: ").append(it) }
        if (d.intent == Niat.KODE) kb.cari(t, 1).firstOrNull()?.let { hint.append("Contoh lokal: ").append(it.c) }
        val r = Llm.tanya(app, history, t, hint.toString(), mood.sekarang().name.lowercase()) ?: return null
        history.add(Pair(t, r))
        while (history.size > 6) history.removeAt(0)
        if (r.length <= 400 && d.intent != Niat.DEBUG) chat.ajar(t, r)  // belajar agar bisa dijawab offline nanti
        return r
    }

    // ---- dipanggil timer: bicara sendiri setelah diam, atau pertanyaan tak dijawab ----
    fun tick(): String? {
        mood.tick()?.let { return it }
        val p = pending
        if (p != null && System.currentTimeMillis() - p.t > 60_000) {
            pending = null
            abai++
            mood.tambah(Em.SEDIH, 0.15)
            if (abai >= 3) mood.tambah(Em.NGAMBEK, 0.5)
            return "Hmmm, baiklah."
        }
        return null
    }

    // ---- dipanggil saat layar berubah (dari akses layar) ----
    private fun jelaskan(s: String): String? {
        if (Decision.adaError(s)) dbg.analisis(s)?.let { return it }
        if (s.length <= 80) {
            val h = kb.cari(s, 1)
            if (h.isNotEmpty()) return "▸ ${h[0].j} [${h[0].b}]\n${h[0].c}"
        }
        return chat.jawab("apa itu $s")
    }

    fun layar(pkg: String, teks: String, sel: String?): String? {
        if (mood.sedangDiam() || pkg in Aksi.BLOKIR) return null
        val now = System.currentTimeMillis()
        if (!sel.isNullOrBlank() && sel.length >= 3 && sel != lastSel) {
            lastSel = sel
            val j = jelaskan(sel)
            if (j != null) return "Kamu menyorot: \"${sel.take(40)}\"\n$j"
        }
        if (Decision.adaError(teks)) {
            val key = Regex("(\\w*Error|Exception)[^\\n]*").find(teks)?.value ?: teks.take(60)
            if (key != lastErr && now - tErr > 30_000) {
                val a = dbg.analisis(teks)
                if (a != null) {
                    lastErr = key
                    tErr = now
                    return "Aku lihat error di layarmu:\n$a"
                }
            }
        }
        if (mood.sekarang() == Em.NGAMBEK) return null
        val kat = Kat.kategori(pkg) ?: return null
        if (kat != katNow) { katNow = kat; stabil = 1; return null }
        stabil++
        if (pending != null || now - tAsk < 90_000 || !(stabil == 2 || now - tAsk > 300_000)) return null
        tAsk = now
        if (kat == "lain") {
            val n = pkg.substringAfterLast('.')
            pending = Tanya("apa itu $n", null, now)
            return "Kamu lagi buka $n? Itu apa sih?"
        }
        val q = Kat.QL[kat]?.random() ?: return null
        pending = Tanya("kamu lagi apa saat ${Kat.LABEL[kat]}", kat, now)
        return q
    }
}
