package id.mini.karakter

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ll = LinearLayout(this)
        ll.orientation = LinearLayout.VERTICAL
        ll.setPadding(40, 60, 40, 40)
        val info = TextView(this)
        info.text = "MINI\nAsisten kode & teman ngobrol.\nOffline = otak lokal. Online (ada internet + API diisi) = pakai AI online.\n\nLangkah: 1 → 2 → 4 → 3"
        info.textSize = 16f
        ll.addView(info)
        ll.addView(tombol("1. Izinkan tampil di atas app lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        ll.addView(tombol("2. Aktifkan akses layar (Mini membaca layar)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        ll.addView(tombol("4. Izinkan akses file (cari/baca file)") {
            if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        })
        ll.addView(tombol("3. Mulai Mini") { mulai() })
        ll.addView(tombol("Hentikan Mini") { stopService(Intent(this, FloatingService::class.java)) })

        val p = Llm.pref(this)
        val api = TextView(this)
        api.text = "\nMode online (opsional): API chat kompatibel OpenAI. Isi sesuai dokumentasi penyedia pilihanmu. Pesan chat dikirim ke penyedia itu hanya saat online; isi layar tidak pernah dikirim."
        ll.addView(api)
        val url = kolom("Base URL (contoh: https://api.groq.com/openai/v1)", p.getString("url", ""), false)
        val model = kolom("Nama model (dari penyedia)", p.getString("model", ""), false)
        val key = kolom("API key", p.getString("key", ""), true)
        ll.addView(url)
        ll.addView(model)
        ll.addView(key)
        ll.addView(tombol("Simpan pengaturan online") {
            p.edit().putString("url", url.text.toString().trim()).putString("model", model.text.toString().trim())
                .putString("key", key.text.toString().trim()).apply()
            Toast.makeText(this, "Tersimpan.", Toast.LENGTH_SHORT).show()
        })
        val sv = ScrollView(this)
        sv.addView(ll)
        setContentView(sv)
    }

    private fun kolom(hint: String, isi: String?, rahasia: Boolean): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(isi ?: "")
        e.setSingleLine(true)
        e.inputType = if (rahasia) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
        return e
    }

    private fun tombol(t: String, aksi: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setOnClickListener { aksi() }
        return b
    }

    private fun mulai() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan tampil di atas app lain dulu (tombol 1).", Toast.LENGTH_LONG).show()
            return
        }
        val i = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        Toast.makeText(this, "Mini aktif. Ketuk wajahnya untuk ngobrol.", Toast.LENGTH_SHORT).show()
    }
}
