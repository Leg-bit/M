package id.mini.karakter

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

// Membaca teks layar secara lokal (tanpa internet) agar Mini tahu kamu sedang apa.
class LayarService : AccessibilityService() {
    private var tLast = 0L
    private var sel: String? = null

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        var paksa = false
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED) {
            val t = (e.source?.text ?: e.text.firstOrNull())?.toString()
            if (t != null && e.fromIndex >= 0 && e.toIndex > e.fromIndex && e.toIndex <= t.length) {
                sel = t.substring(e.fromIndex, e.toIndex)
                paksa = true
            }
        }
        val now = System.currentTimeMillis()
        if (!paksa && now - tLast < 2500) return
        tLast = now
        val teks = kumpul(rootInActiveWindow)
        val s = sel
        sel = null
        Shared.onLayar(this, pkg, teks, s)
    }

    private fun kumpul(root: AccessibilityNodeInfo?): String {
        if (root == null) return ""
        val sb = StringBuilder()
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        var n = 0
        while (q.isNotEmpty() && n < 300 && sb.length < 4000) {
            val nd = q.removeFirst()
            n++
            if (!nd.isPassword) {
                val t = nd.text
                if (!t.isNullOrBlank()) sb.append(t).append('\n')
            }
            for (i in 0 until nd.childCount) nd.getChild(i)?.let { q.add(it) }
        }
        return sb.toString()
    }

    override fun onInterrupt() {}
}
