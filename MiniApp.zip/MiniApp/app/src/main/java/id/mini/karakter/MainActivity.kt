package id.mini.karakter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ll = LinearLayout(this)
        ll.orientation = LinearLayout.VERTICAL
        ll.setPadding(40, 60, 40, 40)
        val info = TextView(this)
        info.text = "MINI\nAsisten kode & teman ngobrol (offline)\n\n1. Izinkan tampil di atas app lain\n2. Aktifkan akses layar (cari \"Mini membaca layar\")\n3. Mulai Mini"
        info.textSize = 16f
        ll.addView(info)
        ll.addView(tombol("1. Izinkan tampil di atas app lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        ll.addView(tombol("2. Aktifkan akses layar") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        ll.addView(tombol("3. Mulai Mini") { mulai() })
        ll.addView(tombol("Hentikan Mini") { stopService(Intent(this, FloatingService::class.java)) })
        val sv = ScrollView(this)
        sv.addView(ll)
        setContentView(sv)
    }

    private fun tombol(t: String, aksi: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setOnClickListener { aksi() }
        return b
    }

    private fun mulai() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan tampil di atas app lain dulu (tombol 1).", Toast.LENGTH_LONG).show()
            return
        }
        val i = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        Toast.makeText(this, "Mini aktif. Ketuk wajahnya untuk ngobrol.", Toast.LENGTH_SHORT).show()
    }
}
