package id.mini.karakter

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// Obrolan berbasis pencocokan + belajar dari /ajar dan /koreksi (disimpan di HP).
class Chat(ctx: Context) {
    private val data = HashMap<String, MutableList<String>>()
    private val user = HashMap<String, MutableList<String>>()
    private val kunci = HashMap<String, Set<String>>()
    private var lastQ: String? = null
    private val file = File(ctx.filesDir, "ajar.json")

    init {
        muat(try { ctx.assets.open("chat.json").bufferedReader().use { it.readText() } } catch (e: Exception) { "{}" }, data)
        if (file.exists()) {
            muat(try { file.readText() } catch (e: Exception) { "{}" }, user)
            data.putAll(user)
        }
    }

    private fun muat(js: String, target: HashMap<String, MutableList<String>>) {
        try {
            val o = JSONObject(js)
            val ks = o.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                val a = o.getJSONArray(k)
                target[k] = MutableList(a.length()) { i -> a.getString(i) }
                kunci[k] = k.split(" ").toSet()
            }
        } catch (e: Exception) {
        }
    }

    private fun simpan() {
        val o = JSONObject()
        for ((k, v) in user) o.put(k, JSONArray(v))
        try { file.writeText(o.toString()) } catch (e: Exception) { }
    }

    fun jawab(t: String): String? {
        val q = tok(t).toSet()
        if (q.isEmpty()) return null
        var best: String? = null
        var bs = 0.0
        for ((k, ks) in kunci) {
            val j = q.intersect(ks).size.toDouble() / q.union(ks).size
            if (j > bs) { bs = j; best = k }
        }
        if (best == null || bs < 0.5) return null
        lastQ = tok(t).joinToString(" ")
        return data[best]!!.random()
    }

    fun ajar(q: String, a: String) {
        val key = tok(q).joinToString(" ")
        if (key.isEmpty() || a.isEmpty()) return
        data[key] = mutableListOf(a)
        user[key] = mutableListOf(a)
        kunci[key] = key.split(" ").toSet()
        simpan()
    }

    fun koreksi(a: String): Boolean {
        val q = lastQ ?: return false
        ajar(q, a)
        return true
    }
}
