package id.mini.karakter

import android.content.Context
import org.json.JSONArray

data class Snip(val b: String, val k: Set<String>, val j: String, val c: String)

// Perpustakaan syntax offline.
class Kb(ctx: Context) {
    private val data: List<Snip> = try {
        val arr = JSONArray(ctx.assets.open("snippets.json").bufferedReader().use { it.readText() })
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Snip(o.getString("b"), tok(o.getString("k") + " " + o.getString("j")).toSet(), o.getString("j"), o.getString("c"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    companion object {
        val STOP = setOf("cara", "gimana", "bagaimana", "contoh", "apa", "itu", "di", "dan", "yang", "untuk", "buat", "buatkan",
            "bikin", "tulis", "tuliskan", "kode", "syntax", "sintaks", "dengan", "pakai", "ke", "dari", "ya", "tolong", "bisa",
            "kah", "cari", "perintah", "command", "code", "program", "script")
        val LANG = mapOf("python" to "python", "py" to "python", "pydroid" to "python", "js" to "js", "javascript" to "js",
            "node" to "js", "nodejs" to "js", "mcpe" to "mcpe", "minecraft" to "mcpe", "bedrock" to "mcpe",
            "arduino" to "arduino", "cpp" to "arduino", "bash" to "bash", "termux" to "bash", "shell" to "bash")
    }

    fun cari(q: String, n: Int = 3): List<Snip> {
        val qt = tok(q)
        val lang = qt.firstNotNullOfOrNull { LANG[it] }
        val kata = qt.filter { it !in STOP && it !in LANG }
        if (kata.isEmpty()) return emptyList()
        val hasil = ArrayList<Pair<Snip, Double>>()
        for (s in data) {
            var sk = 0.0
            for (w in kata) {
                if (w in s.k) sk += 2.0
                else if (w.length > 3 && s.k.any { it.length > 3 && (it.startsWith(w) || w.startsWith(it)) }) sk += 1.0
            }
            if (sk < 2.0) continue
            if (lang != null) sk += if (s.b == lang) 2.5 else -1.0
            hasil.add(Pair(s, sk))
        }
        return hasil.sortedByDescending { it.second }.take(n).map { it.first }
    }
}
