package id.mini.karakter

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var brain: Brain
    private lateinit var tokoh: CharacterView
    private lateinit var avatar: CharacterView
    private lateinit var panel: LinearLayout
    private lateinit var box: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var meter: TextView
    private lateinit var bubble: TextView
    private lateinit var lpT: WindowManager.LayoutParams
    private lateinit var lpP: WindowManager.LayoutParams
    private lateinit var lpB: WindowManager.LayoutParams
    private var panelOn = false
    private var bubbleOn = false
    private val h = Handler(Looper.getMainLooper())
    private var sx = 0
    private var sy = 0
    private var tx = 0f
    private var ty = 0f
    private var moved = false
    private val hideB = Runnable { sembunyiBubble() }
    private val timer = object : Runnable {
        override fun run() {
            tik()
            h.postDelayed(this, 3000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    @Suppress("DEPRECATION")
    private fun tipe(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    @Suppress("DEPRECATION")
    private fun notif(): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "mini") else Notification.Builder(this)
        return b.setContentTitle("Mini aktif").setContentText("Ketuk wajah di layar untuk ngobrol")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun kotak(fill: String, stroke: String, r: Int = 6): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(fill))
        g.setStroke(dp(1), Color.parseColor(stroke))
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun label(t: String, warna: String, ukuran: Float, tebal: Boolean): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(Color.parseColor(warna))
        v.textSize = ukuran
        v.typeface = if (tebal) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE
        return v
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel("mini", "Mini", NotificationManager.IMPORTANCE_LOW))
        }
        startForeground(1, notif())
        brain = Shared.brain(this)
        Shared.ui = this
        val dm = resources.displayMetrics

        tokoh = CharacterView(this)
        lpT = WindowManager.LayoutParams(WC, WC, tipe(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lpT.gravity = Gravity.TOP or Gravity.START
        lpT.x = dp(8)
        lpT.y = dp(200)
        tokoh.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lpT.x; sy = lpT.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) + abs(dy) > dp(6)) moved = true
                    if (moved) { lpT.x = sx + dx; lpT.y = sy + dy; wm.updateViewLayout(tokoh, lpT); sembunyiBubble() }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) { sembunyiBubble(); togglePanel() }; true }
                else -> false
            }
        }

        bubble = label("", "#FFFFFF", 12f, false)
        bubble.background = kotak("#F0070B1A", "#FFB020")
        bubble.setPadding(dp(10), dp(8), dp(10), dp(8))
        bubble.maxWidth = (dm.widthPixels * 0.7).toInt()
        bubble.setOnClickListener { sembunyiBubble(); if (!panelOn) togglePanel() }
        lpB = WindowManager.LayoutParams(WC, WC, tipe(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lpB.gravity = Gravity.TOP or Gravity.START

        bangunPanel()
        lpP = WindowManager.LayoutParams((dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.7).toInt(), tipe(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
        lpP.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lpP.y = dp(30)
        lpP.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        wm.addView(tokoh, lpT)
        h.post(timer)
        h.postDelayed({ say("Halo! Aku Mini. Aktifkan akses layar supaya aku bisa lihat layarmu, atau ketuk aku untuk ngobrol.") }, 800)
    }

    private fun bangunPanel() {
        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = kotak("#F0070B1A", "#33E6FF")
        panel.setPadding(dp(8), dp(8), dp(8), dp(8))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(label("MINI", "#33E6FF", 13f, true), LinearLayout.LayoutParams(0, WC, 1f))
        meter = label("", "#FFD23F", 11f, false)
        head.addView(meter)
        val x = label("  ✕", "#FF4D6D", 16f, true)
        x.setOnClickListener { togglePanel() }
        head.addView(x)
        panel.addView(head)

        val fr = FrameLayout(this)
        fr.background = kotak("#0A1020", "#33E6FF", 4)
        avatar = CharacterView(this)
        fr.addView(avatar, FrameLayout.LayoutParams(MP, MP))
        val st = label("MINI // ONLINE", "#33E6FF", 10f, false)
        val sp = FrameLayout.LayoutParams(WC, WC)
        sp.gravity = Gravity.TOP or Gravity.START
        sp.setMargins(dp(6), dp(2), 0, 0)
        fr.addView(st, sp)
        val fp = LinearLayout.LayoutParams(MP, dp(110))
        fp.topMargin = dp(6)
        panel.addView(fr, fp)

        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        scroll = ScrollView(this)
        scroll.addView(box)
        val lp = LinearLayout.LayoutParams(MP, 0, 1f)
        lp.topMargin = dp(6)
        panel.addView(scroll, lp)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        input = EditText(this)
        input.hint = "Talk to Mini..."
        input.setHintTextColor(Color.parseColor("#6C7A99"))
        input.setTextColor(Color.WHITE)
        input.textSize = 14f
        input.typeface = Typeface.MONOSPACE
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        input.maxLines = 4
        input.background = kotak("#0A1020", "#33E6FF", 4)
        input.setPadding(dp(8), dp(6), dp(8), dp(6))
        val send = label(" ▶ ", "#33E6FF", 22f, true)
        send.setOnClickListener { kirim() }
        row.addView(input, LinearLayout.LayoutParams(0, WC, 1f))
        row.addView(send)
        val rp = LinearLayout.LayoutParams(MP, WC)
        rp.topMargin = dp(6)
        panel.addView(row, rp)
    }

    private fun pesan(t: String, user: Boolean) {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.addView(label(if (user) "YOU" else "MINI // INCOMING TRANSMISSION", if (user) "#7C8BA8" else "#FFB020", 9f, false))
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.WHITE)
        tv.textSize = 13f
        tv.typeface = Typeface.MONOSPACE
        tv.setPadding(dp(8), dp(5), dp(8), dp(5))
        tv.background = kotak("#0F1830", if (user) "#3B5BDB" else "#33E6FF", 4)
        tv.setTextIsSelectable(true)
        wrap.addView(tv)
        val p = LinearLayout.LayoutParams(MP, WC)
        p.topMargin = dp(6)
        box.addView(wrap, p)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun togglePanel() {
        if (panelOn) {
            wm.removeView(panel)
            panelOn = false
        } else {
            wm.addView(panel, lpP)
            panelOn = true
            segarkan()
        }
    }

    private fun sembunyiBubble() {
        if (bubbleOn) {
            try { wm.removeView(bubble) } catch (e: Exception) { }
            bubbleOn = false
        }
    }

    fun say(t: String) {
        pesan(t, false)
        segarkan()
        if (panelOn) return
        bubble.text = if (t.length > 170) t.take(170) + "… (ketuk)" else t
        val tinggi = resources.displayMetrics.heightPixels
        lpB.x = maxOf(0, lpT.x)
        lpB.y = if (lpT.y > tinggi / 2) maxOf(0, lpT.y - dp(90)) else lpT.y + dp(100)
        if (bubbleOn) wm.updateViewLayout(bubble, lpB) else { wm.addView(bubble, lpB); bubbleOn = true }
        h.removeCallbacks(hideB)
        h.postDelayed(hideB, 10000)
    }

    private fun kirim() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        pesan(t, true)
        val r = brain.balas(t)
        if (r != null && r.isNotEmpty()) pesan(r, false)
        segarkan()
    }

    private fun segarkan() {
        val e = brain.mood.sekarang()
        tokoh.setEmosi(e)
        avatar.setEmosi(e)
    }

    private fun tik() {
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val pct = 100 - (mi.availMem * 100 / mi.totalMem)
        meter.text = "RAM $pct%"
        val x = brain.tick()
        if (x != null) say(x)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        Shared.ui = null
        try { wm.removeView(tokoh) } catch (e: Exception) { }
        if (panelOn) try { wm.removeView(panel) } catch (e: Exception) { }
        sembunyiBubble()
        super.onDestroy()
    }
}
