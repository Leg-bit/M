package id.mini.karakter

import android.content.Context
import org.json.JSONArray

class Aturan(val re: Regex, val b: String, val t: String, val s: String)

// Pendeteksi error: mencocokkan pesan error dengan aturan offline.
class Debugger(ctx: Context) {
    private val aturan: List<Aturan> = try {
        val arr = JSONArray(ctx.assets.open("errors.json").bufferedReader().use { it.readText() })
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Aturan(Regex(o.getString("p"), RegexOption.IGNORE_CASE), o.getString("b"), o.getString("t"), o.getString("s"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun isi(t: String, m: MatchResult): String {
        var r = t
        for (i in 1 until m.groupValues.size) r = r.replace("\$" + i, m.groupValues[i])
        return r
    }

    fun analisis(teks: String): String? {
        val t = teks.take(4000)
        val hasil = ArrayList<Pair<Aturan, MatchResult>>()
        for (a in aturan) {
            val m = a.re.find(t)
            if (m != null) hasil.add(Pair(a, m))
        }
        if (hasil.isEmpty()) return null
        val baris = Regex("line (\\d+)", RegexOption.IGNORE_CASE).findAll(t).map { it.groupValues[1] }.lastOrNull()
        val sb = StringBuilder()
        for ((a, m) in hasil.take(2)) {
            sb.append("[").append(a.b).append("] ").append(isi(a.t, m)).append("\nSolusi: ").append(isi(a.s, m)).append("\n\n")
        }
        if (baris != null) sb.append("Mulai periksa dari baris ").append(baris).append(".")
        return sb.toString().trim()
    }
}
