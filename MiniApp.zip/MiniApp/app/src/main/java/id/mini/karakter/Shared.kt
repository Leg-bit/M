package id.mini.karakter

import android.content.Context

object Shared {
    private var brain: Brain? = null
    var ui: FloatingService? = null

    fun brain(ctx: Context): Brain {
        val b = brain ?: Brain(ctx.applicationContext)
        brain = b
        return b
    }

    fun onLayar(ctx: Context, pkg: String, teks: String, sel: String?) {
        val u = ui ?: return
        val msg = brain(ctx).layar(pkg, teks, sel) ?: return
        u.say(msg)
    }
}
