package id.mini.karakter

fun tok(t: String): List<String> =
    t.lowercase().replace(Regex("[^a-z0-9\\s]"), " ").split(Regex("\\s+")).filter { it.isNotEmpty() }

enum class Niat { DEBUG, KODE, CHAT, DIAM, BICARA, TEACH, CORRECT }

data class Keputusan(val intent: Niat, val skor: Double, val ragu: Boolean = false)

// Pengambil keputusan: memutuskan modul mana yang menjawab.
object Decision {
    val DIAM = Regex("^/?diam(?: dulu)?(?: (\\d+) ?(detik|dtk|menit|mnt|jam))?$")
    private val TRACE = Regex("Traceback|\\w+Error\\b|Exception|not declared|not found|npm ERR|Cannot find module|Cannot read prop")
    private val ERR_LAYAR = Regex("Traceback \\(most recent call last\\)|\\b\\w+Error: .+|Uncaught .+Error|was not declared in this scope|command not found|npm ERR!|Cannot find module")
    private val DEBUG_KW = listOf("error", "eror", "bug", "gagal", "crash", "exception", "traceback", "tidak jalan", "nggak jalan", "gak jalan", "not defined", "undefined", "macet")
    private val TANYA = setOf("syntax", "sintaks", "cara", "gimana", "bagaimana", "contoh", "perintah", "command", "rumus", "cari")
    private val MINTA = setOf("buatkan", "buat", "bikin", "tulis", "tuliskan", "generate")
    private val NOUN = setOf("kode", "code", "program", "script", "skrip", "fungsi", "loop", "class")

    fun adaError(t: String): Boolean = ERR_LAYAR.containsMatchIn(t)

    fun putuskan(raw: String): Keputusan {
        val l = raw.trim().lowercase()
        if (l.startsWith("/ajar ")) return Keputusan(Niat.TEACH, 9.0)
        if (l.startsWith("/koreksi ")) return Keputusan(Niat.CORRECT, 9.0)
        if (l == "/bicara" || l == "bicara" || l == "/bangun") return Keputusan(Niat.BICARA, 9.0)
        if (DIAM.matches(l)) return Keputusan(Niat.DIAM, 9.0)
        val w = tok(l)
        var debug = 0.0
        var kode = 0.0
        if (TRACE.containsMatchIn(raw)) debug += 3.0
        debug += 1.5 * minOf(2, DEBUG_KW.count { l.contains(it) })
        if (Regex("line \\d+").containsMatchIn(l)) debug += 1.0
        kode += 1.2 * w.count { it in TANYA }
        if (w.any { it in Kb.LANG }) kode += 1.0
        val first = w.firstOrNull()
        if (first != null && first in MINTA) kode += 1.5
        if (w.any { it in NOUN }) kode += 1.0
        if (raw.contains("?")) kode += 0.4
        if (maxOf(debug, kode) < 1.5) return Keputusan(Niat.CHAT, 0.8)
        val ragu = debug >= 1.5 && kode >= 1.5 && Math.abs(debug - kode) < 0.8
        return if (debug >= kode) Keputusan(Niat.DEBUG, debug, ragu) else Keputusan(Niat.KODE, kode, ragu)
    }
}
