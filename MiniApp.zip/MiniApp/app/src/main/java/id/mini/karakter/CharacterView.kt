package id.mini.karakter

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import java.util.Random
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// Karakter glitch gambar sendiri (Canvas): aura bergerigi, wajah berlian, ekspresi ikut mood.
class CharacterView(ctx: Context) : View(ctx) {
    private var em = Em.NETRAL
    private val rnd = Random()
    private var t = 0
    private var glitch = false
    private var shift = 0f
    private var band0 = 0f
    private var band1 = 0f
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private val loop = object : Runnable {
        override fun run() {
            t++
            glitch = rnd.nextInt(100) < 14
            if (glitch) {
                shift = (rnd.nextInt(17) - 8) * d
                band0 = rnd.nextFloat() * height
                band1 = band0 + rnd.nextFloat() * height * 0.25f
            }
            invalidate()
            postDelayed(this, 90)
        }
    }

    fun setEmosi(e: Em) { em = e; invalidate() }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(loop) }
    override fun onDetachedFromWindow() { removeCallbacks(loop); super.onDetachedFromWindow() }

    override fun onMeasure(w: Int, h: Int) {
        val s = (96 * d).toInt()
        setMeasuredDimension(resolveSize(s, w), resolveSize(s, h))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (glitch) { c.save(); c.translate(-shift, 0f); gambar(c, w, h, true); c.restore() }
        gambar(c, w, h, false)
        if (glitch) { c.save(); c.clipRect(0f, band0, w, band1); c.translate(shift * 2, 0f); gambar(c, w, h, false); c.restore() }
        p.style = Paint.Style.FILL
        p.color = Color.argb(40, 0, 0, 0)
        var y = 0f
        while (y < h) { c.drawRect(0f, y, w, y + d, p); y += d * 4 }
    }

    private fun aura(): Int = when (em) {
        Em.MARAH -> Color.parseColor("#FF1744")
        Em.SEDIH -> Color.parseColor("#3D5AFE")
        Em.CERIA -> Color.parseColor("#FF3D9A")
        Em.NGAMBEK -> Color.parseColor("#5B2A86")
        Em.PENASARAN -> Color.parseColor("#FFB020")
        else -> Color.parseColor("#7B2FF7")
    }

    private fun gambar(c: Canvas, w: Float, h: Float, ghost: Boolean) {
        val cx = w / 2
        val cy = h / 2 + sin(t * 0.3).toFloat() * d * 2
        val r = min(w, h) / 2f * 0.95f
        // aura bergerigi
        path.reset()
        val n = 14
        for (i in 0 until n * 2) {
            val a = Math.PI * i / n
            val j = ((i * 37 + t / 2) % 5) / 10f
            val rr = if (i % 2 == 0) r * (0.75f + j * 0.6f) else r * 0.4f
            val x = cx + cos(a).toFloat() * rr
            val y = cy + sin(a).toFloat() * rr
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        p.style = Paint.Style.FILL
        p.color = if (ghost) Color.argb(120, 0, 229, 255) else aura()
        c.drawPath(path, p)
        if (ghost) return
        // tanduk
        p.color = Color.parseColor("#0B0B14")
        path.reset(); path.moveTo(cx - 0.28f * r, cy - 0.15f * r); path.lineTo(cx - 0.38f * r, cy - 0.62f * r); path.lineTo(cx - 0.08f * r, cy - 0.32f * r); path.close(); c.drawPath(path, p)
        path.reset(); path.moveTo(cx + 0.28f * r, cy - 0.15f * r); path.lineTo(cx + 0.38f * r, cy - 0.62f * r); path.lineTo(cx + 0.08f * r, cy - 0.32f * r); path.close(); c.drawPath(path, p)
        // wajah berlian
        p.color = Color.parseColor("#5CF2D6")
        path.reset(); path.moveTo(cx, cy - 0.42f * r); path.lineTo(cx + 0.3f * r, cy); path.lineTo(cx, cy + 0.42f * r); path.lineTo(cx - 0.3f * r, cy); path.close()
        c.drawPath(path, p)
        // mata
        val ey = cy - 0.04f * r
        val ex = 0.11f * r
        p.style = Paint.Style.FILL
        if (em == Em.NGAMBEK) {
            p.style = Paint.Style.STROKE; p.strokeWidth = d * 2; p.color = Color.BLACK
            c.drawLine(cx - ex - 0.06f * r, ey, cx - ex + 0.06f * r, ey, p)
            c.drawLine(cx + ex - 0.06f * r, ey, cx + ex + 0.06f * r, ey, p)
        } else if (em == Em.CERIA) {
            p.style = Paint.Style.STROKE; p.strokeWidth = d * 2; p.color = Color.BLACK
            for (s in intArrayOf(-1, 1)) {
                path.reset(); path.moveTo(cx + s * ex - 0.06f * r, ey + 0.02f * r); path.quadTo(cx + s * ex, ey - 0.08f * r, cx + s * ex + 0.06f * r, ey + 0.02f * r)
                c.drawPath(path, p)
            }
        } else {
            val rad = if (em == Em.SEDIH) 0.055f * r else 0.07f * r
            p.color = Color.parseColor("#FFD23F")
            c.drawCircle(cx - ex, ey, rad, p); c.drawCircle(cx + ex, ey, rad, p)
            p.color = Color.BLACK
            c.drawCircle(cx - ex, ey, rad * 0.45f, p); c.drawCircle(cx + ex, ey, rad * 0.45f, p)
        }
        // alis & mulut
        p.style = Paint.Style.STROKE; p.strokeWidth = d * 2; p.color = Color.BLACK
        if (em == Em.MARAH) {
            c.drawLine(cx - 0.2f * r, ey - 0.1f * r, cx - 0.04f * r, ey - 0.04f * r, p)
            c.drawLine(cx + 0.2f * r, ey - 0.1f * r, cx + 0.04f * r, ey - 0.04f * r, p)
        } else if (em == Em.SEDIH) {
            c.drawLine(cx - 0.2f * r, ey - 0.04f * r, cx - 0.04f * r, ey - 0.1f * r, p)
            c.drawLine(cx + 0.2f * r, ey - 0.04f * r, cx + 0.04f * r, ey - 0.1f * r, p)
        }
        val my = cy + 0.17f * r
        path.reset()
        when (em) {
            Em.CERIA -> { path.moveTo(cx - 0.12f * r, my - 0.03f * r); path.quadTo(cx, my + 0.12f * r, cx + 0.12f * r, my - 0.03f * r) }
            Em.SEDIH -> { path.moveTo(cx - 0.1f * r, my + 0.05f * r); path.quadTo(cx, my - 0.08f * r, cx + 0.1f * r, my + 0.05f * r) }
            Em.MARAH -> { path.moveTo(cx - 0.12f * r, my); path.lineTo(cx - 0.06f * r, my + 0.05f * r); path.lineTo(cx, my); path.lineTo(cx + 0.06f * r, my + 0.05f * r); path.lineTo(cx + 0.12f * r, my) }
            Em.NGAMBEK -> { path.moveTo(cx - 0.1f * r, my + 0.03f * r); path.lineTo(cx + 0.1f * r, my - 0.03f * r) }
            Em.PENASARAN -> path.addCircle(cx, my, 0.04f * r, Path.Direction.CW)
            else -> { path.moveTo(cx - 0.09f * r, my); path.lineTo(cx + 0.09f * r, my) }
        }
        c.drawPath(path, p)
    }
}
