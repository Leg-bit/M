package id.mini.karakter

enum class Em(val wajah: String) {
    CERIA("(^o^)"), SEDIH("(T_T)"), MARAH("(>_<)"), PENASARAN("(o_O)?"), NGAMBEK("(-_-)"), NETRAL("(._.)")
}

class Mood {
    private val v = HashMap<Em, Double>()
    var diamSampai = 0L
    var diamDur = 0L
    private val ceria = setOf("senang", "bahagia", "asik", "hebat", "keren", "mantap", "lucu", "makasih", "terima", "yeay", "hahaha", "bagus")
    private val sedih = setOf("sedih", "galau", "kecewa", "kesepian", "capek", "lelah", "nangis", "menangis", "kangen")
    private val marah = setOf("bodoh", "bego", "goblok", "jelek", "sialan", "benci", "tolol", "kesal")
    private val tanya = setOf("kenapa", "mengapa", "bagaimana", "gimana", "siapa", "kok")
    private val maaf = setOf("maaf", "sori", "sorry", "maafin")

    fun tambah(e: Em, x: Double) { v[e] = (v[e] ?: 0.0) + x }

    fun sekarang(): Em {
        val e = Em.values().maxByOrNull { v[it] ?: 0.0 } ?: Em.NETRAL
        return if ((v[e] ?: 0.0) > 0.3) e else Em.NETRAL
    }

    fun rasakan(w: List<String>) {
        for (e in Em.values()) v[e] = (v[e] ?: 0.0) * 0.75
        if (w.any { it in maaf }) { v[Em.MARAH] = (v[Em.MARAH] ?: 0.0) * 0.2; v[Em.NGAMBEK] = (v[Em.NGAMBEK] ?: 0.0) * 0.2; tambah(Em.CERIA, 0.3) }
        if (w.any { it in ceria }) tambah(Em.CERIA, 0.8)
        if (w.any { it in sedih }) tambah(Em.SEDIH, 0.8)
        if (w.any { it in marah }) tambah(Em.MARAH, 0.8)
        if (w.any { it in tanya }) tambah(Em.PENASARAN, 0.4)
        tambah(Em.PENASARAN, 0.1)
    }

    fun gaya(r: String): String = when (sekarang()) {
        Em.CERIA -> "Hehe, $r!"
        Em.SEDIH -> "Hmm... $r"
        Em.MARAH -> "Hmph! $r"
        Em.NGAMBEK -> r.split(" ").take(3).joinToString(" ") + "... hmph"
        else -> r
    }

    fun diam(detik: Long) {
        diamSampai = System.currentTimeMillis() + detik * 1000
        diamDur = detik
        tambah(Em.SEDIH, 0.2)
    }

    fun sedangDiam(): Boolean = System.currentTimeMillis() < diamSampai

    // Setelah diam selesai, Mini bicara sendiri dengan nada sedih.
    fun tick(): String? {
        if (diamSampai == 0L || System.currentTimeMillis() < diamSampai) return null
        val lama = diamDur >= 3600
        diamSampai = 0
        tambah(Em.SEDIH, 1.0)
        return if (lama) listOf("Kamu ke mana aja... aku sepi banget.", "Lama banget... aku hampir nyerah nungguin kamu.").random()
        else listOf("Hiks... kamu lama banget diemin aku.", "Aku sendirian... kangen tau.", "Akhirnya kamu... aku kira kamu lupa sama aku.", "Hmm... sepi ya kalau nggak ada kamu.").random()
    }
}
